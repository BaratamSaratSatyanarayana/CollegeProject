<?php
session_start();
?>
<!DOCTYPE html>
<html>

<meta name="viewport" content="width=1024">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
h6 {
  position: relative;
  font-weight: bold;
  color: red;
}
body
{
	background: blue;
}

.formlogin
{
  
background: white;
border-radius: 5px;
position: relative;
margin:5% 5% 0% 5%;
padding-bottom: 7%;
}


a
{
color:red;
font-size: 15px;
font-weight: bold;
}

.icon
{
  position: relative;
margin-left: 28%;
margin-top: -25%;
}
form
{
  position: relative;
margin: -20% 0 0 60%;

}
input
{

position: relative;
height: 50px;
width: 445px;
margin-right: 10%;
margin-bottom: 5%;

}
button
{
height: 40px;
width: 80%;
background-color: #0162CD;
color: white;
font-weight: bold;
font-size: 18px;  
border-radius: 10px;
border:0;
}

.leftImage
{
  position: relative;
margin-left: 7%;
margin-top: 2%;


}

.innerdiv .register
{
margin-left: 37%;
}

.innerdiv
{
  margin-bottom: 5%;
}

</style>
<body>
	<div class="formlogin" style="">
    <img src="LoginImage.jpg" class="leftImage" height="500px" width="500px">
     <img src="icon.png" alt="logo" class="icon" height="5%" width="10%">
    <form action="server_1.php" class="" method="post">
   	<input class="" name="email" type="email" placeholder="Email" autocomplete="off">
	<input class="" name="password" type="password" placeholder="Password">
  <div class="innerdiv">
    <a href="#" class="" style="text-decoration:none;">Forgot Password?</a>
   <a href="Reg.php" class="register" style="text-decoration:none;">Register!!</a> 
  </div>
	<button class="login" type="submit" name="login_user">Login</button>	
  
    

</form>
  

</div>

 <?php
 
                    if(isset($_SESSION["error"])){
                        $error = $_SESSION["error"];
                        echo "<script>
           alert('Wrong Username/Password');
          window.location.href='TempLogin.php';
            </script>";
                    }
                ?>  
</body>
</html>
<?php
    unset($_SESSION["error"]);
?>