<!DOCTYPE html>
<html>
    <head>
    	<style type="text/css" >
    		body
    		{
    			background: linear-gradient( to top right,#3636B2,#02C0FC );
    			background-size: cover;
    			height: 100%;
    			background-repeat: no-repeat;
    		}
    		.formcss
    		{
    			background: white;
    			
    			width: 80%;
    			margin:-22% 2% 6.8%  15%;
    			border-top-left-radius:15%;
    			border-bottom-left-radius: 15%;
    			
    		} 
            select
            {
                color:#3636B2;
                
            }

    		 .heading
    		{

    			position: relative;
    			margin: 2% 0 0 32%;
    			color: white;
    			
    		}
    		form .reg
    		{
    			border:0;
    			background-color:#0162CD;
    			height: 50px;
    			color:white;
    			font-size:25px;
                font-weight: bold;
    			width: 150px;	
    			margin: 2% 0 2% 40%;
    		}

            .login
            {
                border:0;
                background-color:white;
                height: 40px;
                color:#0162CD;
                font-size:22px;
                width: 120px;
                border-radius: 5px;
                font-weight: bold;   
                margin: 2% 0 2% 10%;
            }
    		form select
    		{

    			width:40%;
    			margin:2% 0% 1% 4%;
    			position: relative;
    			height:35px;
    		}

    		.formselectcss
    		{
    			width:40%;
    			margin:2% 0% 2.5% 4%;
    			height:35px;
    		}
    		form input
    		{
    			width:40%;
    			margin:2% 0% 0.5% 4%;
    			height: 35px;
    		}
    		form .imagecss
    		{
    			width: 84.5%;
    			margin:1% 0 0% 4%;
                color:blue;
                height: 35px;
    		}
    		form .inputelementscss
    		{
    			margin-left: 9%;
    		}
    		img
    		{
    			height: 120px;
    			width:120px;
    			position:relative;
    			
    		}
    		.leftcss
    		{
    			width:150px;
    			position: relative;
    			margin:7% 0% 0% 2%;
    			text-align: center;
    		}
    		.leftcss  p
    		{
    			margin-left: 3%;
    			margin-right: 2%;
    			color: white;
    			font-size: 20px;
    		}
            ::placeholder
            {
                color: #3636B2;
            }
            .icon
            {
                margin: -2% 0 0 2%;
            }
            
    	</style>
         <meta name="viewport" content="width=1024">
         <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
         <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    </head>
	
    <body>
        <h2 class="heading">Aditya Institute Of technology and management</h2>
        <img src="icon.png" class="icon">
   <div class="leftcss">
    		
    		<p>You are few seconds away to complete your profile</p>
            <button onClick="window.location='login.php';" class="login">LOGIN</button>
    	</div>
   
    	<div class = "formcss">
        <form action="register.php" onsubmit="return Validate()" class="" enctype="multipart/form-data" method="POST" name="vform">
                                
								

         <div class="" style="">
		 
		 	<div class="inputelementscss">
                   <select class="" name="salut" required="true">
                       <option  value="" disabled selected>Salutation</option>
                       <option value="1">Mr.</option>
                       <option value="2">Mrs.</option>
                       <option value="3">Miss.</option>
                   </select>
         
		           <select class="" name="str" required="true">
			          <option  value="" disabled selected>Stream</option>
			          <option value="1">B.tech</option>
			          <option value="2">M.tech</option>
			          <option value="3">MBA</option>
		           </select>


		          <input class="" name="first" required="true" type="text"  autocomplete="off" placeholder="First Name"> 
		
			      <input class="" name="last" type="text" required="true" autocomplete="off"  placeholder="Last Name">
         
					
		 
      <input class="" name="Qualification" type="text" required="true" autocomplete="off" placeholder="Qualification">
    
      <input class="" name="Designation" type="text" required="true" autocomplete="off" placeholder="Designation">
    
      <input class="" name="email" type="email" placeholder="Email"autocomplete="off" required="true">
	
      <input class="" name="phonenum" id="phone_div" type="number" placeholder="Mobile Number" autocomplete="off" required="true">
      <div id="phone_error"></div>
	


      <input class="" name="Password"  id="password_div" type="password" placeholder="Password"autocomplete="off" required="true">
      
	
	
	  
      <input class="" name="Confirm_Password" id="pass_confirm_div" type="password" placeholder="Confirm Password" autocomplete="off"required="true">
          	   <div id="password_error"></div>
	   

      <input class="" name="Employee_Id" type="text" placeholder="Employee Id" autocomplete="off" required="true">

	
		<select class="" name="department" required="true">
			<option value="" disabled selected>Department</option>
			<option value="1">CSE</option>
			<option value="2">ECE</option>
			<option value="3">EEE</option>
			<option value="4">CIV</option>
			<option value="5">MECH</option>
			<option value="6">IT</option>
		</select>
    
<input name="image" type="file" id="file">
 <!-- style="visibility: hidden;margin-top:0%;height: 55px;width:5px;" class="imagecss" required="true"> -->
         <!-- <button class="imagecss" onclick="document.getElementById('file').click();return true;">Upload Picture</button> -->
        

<button class="reg" type="submit" value="submit" name="submit">Register</button>

</div>

</form>
</div>

</body>
</html> 
 <script src="scripts.js"></script>