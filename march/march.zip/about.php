<!DOCTYPE html>
<html>
<head>
	<title></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<style type="text/css">
		th,td
		{
			padding: 10px;
			height:48px;
			width: 10%;
			font-size: 30px;
			text-align: center;
			font-weight: bold;
			text-transform: capitalize;
		}
        
		
		th
		{
			
			color: red;
		
		}
		td
		{
			
			color: blue;
		
		}
		th .colon
		{
			padding: 0;
		}
		caption
		{
			font-size: 35px;
			color: gray;
		}
		table
		{
		
		}
        i
        {
            position: absolute;
            margin: .5% 0 0 93%;
        }

	</style>
</head>
<body>
<a href="#" style="text-decoration: none;color: #000000;"><i class="fa fa-edit" style="font-size: 40px;"></i></a>
</body>
</html>

<?php
   
   session_start();
   $email    = "";
   $errors = array();


// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'register');	  
	  $sql = "SELECT * FROM data WHERE email = '" . $_SESSION['email'] . "'";
      $results = mysqli_query($db, $sql);
      
      while($row = mysqli_fetch_array($results,MYSQLI_ASSOC))
	  {


		echo "<table border='0'>
		<caption>Personal Information</caption>
        
<tr>

<th>Salutation</th>";
echo "<td>" . $row['salutation'] . "</td>";
echo "</tr>";

echo "<tr>
<th>Stream</th>";
echo "<td>" . $row['stream'] . "</td>";
echo "</tr>";

echo "<tr>
<th>First Name</th>";
echo "<td>" . $row['firstname'] . "</td>";
echo "</tr>";

echo "<tr>
<th>Last Name</th>";
echo "<td>" . $row['lastname'] . "</td>";
echo "</tr>";

echo "<tr>
<th>Qualification</th>";
echo "<td>" . $row['qualification'] . "</td>";
echo "</tr>";

echo "<tr>
<th>Designation</th>";
echo "<td>" . $row['designation'] . "</td>";
echo "</tr>";

echo "<tr>
<th>Email id</th>";
echo "<td>" . $row['email'] . "</td>";
echo "</tr>";

echo "<tr>
<th>Phone Number</th>";
echo "<td>" . $row['phone'] . "</td>";
echo "</tr>";

echo "<tr>
<th>Employee Id</th>";
echo "<td>" . $row['Employee_id'] . "</td>";
echo "</tr>";

echo "<tr>
<th>Department</th>";
echo "<td>" . $row['department'] . "</td>";
echo "</tr>";
  

echo "</table>";
	  }	   

?>