<!DOCTYPE html>
<html>
<style type="text/css">
  body
    {
      background-image: url("back2.jpg");
      background-size: cover;
      background-repeat: no-repeat;
    }

</style>
<head>
	<script>
function showUser(str)
{
if (str=="")
  {
  document.getElementById("txtHint").innerHTML="";
  return;
  }
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("txtHint").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","other.php?q="+str,true);
xmlhttp.send();
}
</script>
<style>
ul {
  list-style-type: none;
  margin: 0;
  padding: 0;
  overflow: hidden;
  border: 1px solid #e7e7e7;
  background-color: blue;
}

li {
  float: left;
}

li  {
  display: block;
  color: blue;
  line-height: 23px;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;

}
li a{
  text-decoration: none;
  color: white;
  font-size: 20px;
  display: block;
  height: 30px;
  position: relative;   
    margin-top: 5%;
    line-height: 23px;
    font-weight: bold;
}




select
{
  cursor: pointer;
	background-color: white;
  color: white;
	  background: blue;
	  border: none;
    font-weight: bold;
    font-size: 20px;
	  height: 30px;
}
</style>
</head>
<body>

<ul>
  <li><select onchange="showUser(this.value)">
  	<option disabled selected>Department</option>
  	<option>CSE</option>
  	<option>ECE</option>
  	<option>EEE</option>
  	<option>MECH</option>
  	<option>CIVIL</option>
  	<option>IT</option>
  </select></li>
  <li><select>
  	<option disabled selected>Year</option>
  	<option>2020</option>
  	<option>2019</option>
  	<option>2018</option>
  	<option>2017</option>
  	<option>2016</option>
  	<option>2015</option>
  </select></li>
 <li><a href="index.php">LOGOUT</a></li>
</ul>
<div id="txtHint"></div>
</body>
</html>

  
</body>
</html>
		   
	 