<?php
   
   session_start();
   $errors = array(); 
  $db = mysqli_connect('localhost', 'root', '', 'register');	  
     
      $department =   $_SESSION['dept'];
	  $sql = "SELECT * FROM data WHERE department = '$department'";
      $results = mysqli_query($db, $sql);
      while($trow = mysqli_fetch_array($results,MYSQLI_ASSOC))
	  {
		?>
<form class="form">
<?php echo $trow["salutation"]." ".$trow["firstname"]." ".$trow["lastname"]?>
<?php echo "&nbsp;&nbsp;&nbsp;&nbsp;";?>
<?php echo '<a href="facw.php?email='.$trow['email'].'" style=""><input type="button" class="submit" value="view"/></a>';?>
</form>
<?php
}
?>