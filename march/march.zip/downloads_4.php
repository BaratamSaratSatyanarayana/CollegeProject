<?php include 'filesLogic_1.php';?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <link rel="stylesheet" href="style.css">
  <style type="text/css">
    td,th
    {
      border-color: black;
      border-width: 3px;
      font-weight: bold;
    }
    i
    {
      font-size: 25px;
      color: black;
    }
  
  </style>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <title>Download files</title>
</head>
<body>
  
  <a href="index_1.php" target="_self" ><i class="fa fa-arrow-left"></i></a>
  
<table>
<thead>
    
    <th style="color: red;font-weight: bold;">Filename</th>
    
    <th style="color: red;font-weight: bold;">Action</th>
    
</thead>
<tbody>
  <?php foreach ($files as $file): ?>
    <tr>
      
      <td style="text-align: center;color: orange;"><?php echo $file['name']; ?></td>
      
    <td style="text-align: center;"><a href="downloads_1.php?file_directory=<?php echo $file['directory'] ?>#toolbar=0&navpanes=0&scrollbar=0" width="500" height="500" style="text-decoration: none;color: orange;" target="_new">View</a>/<a href="downloads_1.php?file_id=<?php echo $file['id'] ?>" style="text-decoration: none;color:orange;" >Download</a></td>
      
    
    </tr>
  <?php endforeach;?>

</tbody>
</table>

</body>
</html>