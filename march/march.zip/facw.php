<?php include 'fac.php';?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <link rel="stylesheet" href="style.css">
  <title>Download files</title>
  <style type="text/css">
    body
    {
      background-image: url(back.jpeg);
      background-size: cover;
    }
    table
    {
      padding: 10px;
      font-weight: bold;
      font-size: 20px;
    }
    td
    {
      color: red;
      text-align: center;
    }
    a
    {
      color: green;
    }
    h3
    {
      
      text-transform: capitalize;
      color:black;
      font-weight: bold;
    }
  </style>
</head>
<body> 
<table>
<h3> Achievements</h3>
<thead>
    
    <th>Filename</th>
    
	<th>Views</th>
         
</thead>
<tbody>
  <?php foreach ($files1 as $file): ?>
   
    <tr>
      
      <td><?php echo $file['name']; ?></td>
      
	  <td style="text-align: center;"><a href="fac.php?file_directory=<?php echo $file['directory'] ?>#toolbar=0&navpanes=0&scrollbar=0" width="500" height="500" target="_blank" style="text-decoration: none;">View</a></td>
    
    </tr>
  <?php endforeach;?>

</tbody>
</table>
<table>
<h3> Publications</h3>
<thead>
    
    <th>Filename</th>
    
	<th>Views</th>
         
</thead>
<tbody>
  <?php foreach ($files2 as $file): ?>
   
    <tr>
      
      <td><?php echo $file['name']; ?></td>
      
	  <td><a href="fac.php?file_directory=<?php echo $file['directory'] ?>#toolbar=0&navpanes=0&scrollbar=0" width="500" height="500" target="_blank">"View"</a></td>
    
    </tr>
  <?php endforeach;?>

</tbody>
</table>
<table>
<h3> Conferences</h3>
<thead>
    
    <th>Filename</th>
    
	<th>Views</th>
         
</thead>
<tbody>
  <?php foreach ($files3 as $file): ?>
   
    <tr>
      
      <td><?php echo $file['name']; ?></td>
      
	  <td><a href="fac.php?file_directory=<?php echo $file['directory'] ?>#toolbar=0&navpanes=0&scrollbar=0" width="500" height="500"target="_blank" >"View"</a></td>
    
    </tr>
  <?php endforeach;?>

</tbody>
</table>
<table>
<h3> Honors & Awards</h3>
<thead>
    
    <th>Filename</th>
    
	<th>Views</th>
         
</thead>
<tbody>
  <?php foreach ($files4 as $file): ?>
   
    <tr>
      
      <td><?php echo $file['name']; ?></td>
      
	  <td><a href="fac.php?file_directory=<?php echo $file['directory'] ?>#toolbar=0&navpanes=0&scrollbar=0" width="500" height="500" target="_blank">"View"</a></td>
    
    </tr>
  <?php endforeach;?>

</tbody>
</table>
</body>
</html>