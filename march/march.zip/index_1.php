<?php include 'filesLogic_1.php';?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Uploads</title>
    <style type="text/css">
      form {
        background: linear-gradient( to top right,#02C0FC,#3636B2 );
  width: 70%;
  height: 450px;  
  margin: 50px 100px 100px 200px;
  padding: 30px;
  border: 3px dashed white;
}
input {
  width: 100%;
  border: 1px solid #f1e1e1;
  display: block;
  padding: 5px 10px;
}
button {
  border: none;
  width: 100%;
  position: relative;
  margin: 4% 0 4% 0px;
  border-radius: 5px;
  background-color:white;
  color: #3636B2;
  height: 40px; 
  font-size: 20px;  
  font-weight: bold;
}
table {
  width: 60%;
  border-collapse: collapse;
  margin: 100px auto;
}
th,
td {
  height: 50px;
  vertical-align: center;
  border: 1px solid black;
}
i
{
  margin: 0 0 0 42%;
  color:white;
}
p
{
  text-align: center;
  color: black;
  font-weight: bold;
  font-size: 20px;
}
a
{
  background-image: linear-gradient( to top right,#02C0FC,#3636B2 );
  position: relative;
  color: white;
  font-size: 20px;  
  padding:10px;
  border-radius: 10px;
  margin: 0 0 0 46.5%;
}

    </style>
  </head>
  <body>
    <div class="container" >
      <div class="row" >
        <form action="index_1.php" method="post" enctype="multipart/form-data"  style="">
          <i class="fa fa-cloud-upload" style="font-size: 150px;"></i>
          <p>Select your file here</p>
          <input type="file" name="myfile"> <br>
          <button type="submit" name="save" style="">Upload</button>
          <p>File type:pdf Only</p>
        </form>
      </div>
      <a href="downloads_1.php" target="_self"  style="text-decoration: none;">View all Files</a>
    </div>
	
    </body>
</html>










