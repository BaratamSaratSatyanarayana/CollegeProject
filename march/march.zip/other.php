<!DOCTYPE html>
<html>
<head>
  <title></title>
  <style type="text/css">
    
    th
    {
      padding: 10px;
      font-size: 25px;
      width: 750px;
      color: blue;
      text-transform: capitalize;
      text-align: center;
    }
    td
    {
      padding: 10px;
      font-size: 25px;
      width: 750px;
      text-transform: capitalize;
      text-align: center;
      font-weight: bold;
    }
    .submit
    {
      background: transparent;
      border:0;
      border-color: yellow;
      font-size: 25px;
      color: red;
      
      height: 25px;
      width: 100%;
    }
    a
    {
       font-size: 25px;
      color: white;
      
      height: 25px;
      width: 100%;
    }
    a:hover
    {
      height: 25px;
      width: 100%;
    }
    table
    {

    }

  </style>
</head>
<body>

</body>
</html>
<?php
if (isset($_GET['q']))
  {
   session_start(); 
  $db = mysqli_connect('localhost', 'root', '', 'register');	   
      $department=$_GET['q'];
	  $sql = "SELECT * FROM data WHERE department = '$department'";
      $results = mysqli_query($db, $sql);
      while($trow = mysqli_fetch_array($results,MYSQLI_ASSOC))
	  {
		   
		$_SESSION['em'] = $trow['email'];
		?>
<form class="form">
<?php $temp = $trow["salutation"]." ".$trow["firstname"]." ".$trow["lastname"];
echo "<table border='0'>
<th>$temp</th>

";
 ?>
<?php $temp1 =  '<a href="facw.php?email='.$trow['email'].'"><input type="button" class="submit" value="View Profile"/></a>';
echo "<td>$temp1</td>";?>
</form>
<?php
echo "</table>";
}
  }
  ?>