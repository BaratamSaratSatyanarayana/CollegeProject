<html>
<body>
<form action="other.php" class="w3-container w3-card-4 w3-light-grey w3-text-yellow w3-margin" enctype="multipart/form-data" method="POST" name="vform">
<select name="dept" method="POST" >
                       <option  value="" disabled selected>Department</option>
                       <option value="cse" name="cse">CSE</option>
                       <option value="ece">ECE</option>
                       <option value="eee">EEE</option>
					   <option value="it">IT</option>
					   <option value="mech">MECH</option>
					   <option value="civil">CIVIL</option>
                   </select>
		<input type="submit" name="submit">
				   </form>
</body>
</html>		   

		   
	 
