<html>
<head>
	<style type="text/css">
		input
		{

      background: transparent;
      border:0;
      border-color: yellow;
      font-size: 25px;
      color: red;
      
      height: 25px;
      width: 100%;
		}
		 th
    {
      padding: 10px;
      font-size: 25px;
      width: 750px;
      color: blue;
      text-transform: capitalize;
      text-align: center;
    }
    td
    {
      padding: 10px;
      font-size: 25px;
      width: 750px;
      text-transform: capitalize;
      text-align: center;
      font-weight: bold;
    }
	</style>
</head>
<body>				  
<?php
  $db = mysqli_connect('localhost', 'root', '', 'register');	  
	  $sql = "SELECT * FROM data";
      $results = mysqli_query($db, $sql); ?>
	  
	  <?php
      while($trow = mysqli_fetch_array($results,MYSQLI_ASSOC))
	  {
		   
		?>
		
<form class="form">
<?php $z =  $trow["salutation"]." ".$trow["firstname"]." ".$trow["lastname"];
echo "<table border=0>
<th>$z</th>
";?>

<?php $z1 =  '<a href="facw.php?email='.$trow['email'].'"><input type="button" class="submit" value="View Profile"/></a>';
echo "<td>$z1</td>";?>

<?php $z2 =  '<a href="super_fac.php?del='.$trow['email'].'" onclick=\'javascript: return confirm("Are You Sure Want to Delete?");\'><input type="button" class="submit" value="Delete Profile"/></a>';
echo "<td>$z2</td>";
echo "</table>";?>

   </form>
   
   
<?php
}
if (isset($_GET['del'])) {	  
$del = $_GET['del'];
mysqli_query($db, "DELETE FROM data WHERE email = '$del'");
$db1 = mysqli_connect('localhost', 'root', '', 'file-management');
$sql1 = "SELECT * FROM files_1";
$results1 = mysqli_query($db1, $sql1);
$del = $_GET['del'];
$tables = array("files_1","files_2","files_3","files_4");
foreach($tables as $table) {
  $query = "DELETE FROM $table WHERE email = '$del'";
  mysqli_query($db1,$query);
}
?>
<meta http-equiv="refresh" content="0; url=super.php">
<?php
}
?>
</body>
</html>
		   
	 
