<?php
   
   session_start();
   $email    = "";
   $errors = array();

// connect to the database
$db = mysqli_connect('localhost', 'root', '', 'register');  
 $sql = "SELECT * FROM data WHERE email = '" . $_SESSION['email'] . "'";
      $results = mysqli_query($db, $sql);
      while($row = mysqli_fetch_array($results,MYSQLI_ASSOC))
 {
echo "<br>";
echo '<img src="data:image;base64,'.base64_encode( $row['image'] ).'" alt="image" >';
 }  

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		img
		{
			width: 230px;
			 height: 180px;
			border-radius:50%;
			margin-left:10%;
			margin-top:2%;
			
		}
	</style>
</head>
<body>

</body>
</html>
