<?php
$db = mysqli_connect('localhost', 'root', '', 'sample');
$fname=$_POST['first'];
$lname=$_POST['last'];
$qual=$_POST['Qualification'];
$des=$_POST['Designation'];
$email=$_POST['email'];
$phno=$_POST['phonenum'];
$pass=$_POST['Password'];
$cpass=$_POST['Confirm_Password'];
$Eid=$_POST['Employee_Id'];
$tempsalu=$_POST['salut'];
$tempstr=$_POST['str'];
$tempdep=$_POST['department'];
$salutarray = array("Mr.", "Mrs.", "Miss.");
$deptarray = array("CSE", "ECE", "EEE", "CIVIL", "MECH", "IT");
$strarray = array("B.tech","M.tech","MBA");
$tempdep=$tempdep-1;
$tempsalu=$tempsalu-1;
$tempstr=$tempstr-1;
if (isset($_POST['submit']))
{
	
	$query = "INSERT INTO data (salutation, stream, firstname, lastname, qualification, designation, email, phone, password, cpassword, Employeeid, department) VALUES('$salutarray[$tempsalu]','$strarray[$tempstr]' ,'$fname', '$lname', '$qual', '$des', '$email', '$phno', '$pass', '$cpass', '$Eid', '$deptarray[$tempdep]')";
	
	 	mysqli_query($db, $query);
		
	header('location: login.php');
	
}
else
{
	echo "fail";
	
}
?>